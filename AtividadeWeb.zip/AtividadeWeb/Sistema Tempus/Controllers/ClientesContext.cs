﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Sistema_Tempus.Controllers
{
    public class ClientesContext: DbContext
    {
        
    }
}